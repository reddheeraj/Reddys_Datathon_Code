import spacy
from sklearn.cluster import AgglomerativeClustering
import numpy as np
from spacy.cli import download

class NLPLayer:
    def __init__(self):
        # Load the pre-trained spaCy model (en_core_web_md provides word vectors)
        try:
            self.nlp = spacy.load('en_core_web_md')
        except OSError:
            download('en_core_web_md')
            self.nlp = spacy.load('en_core_web_md')

    def get_word_embeddings(self, words):
        """
        Convert words into their embeddings using spaCy's word vectors.
        """
        embeddings = []
        for word in words:
            doc = self.nlp(word)  # Process the word
            embeddings.append(doc.vector)  # Get the word's vector (embedding)
        return embeddings

    def get_initial_groups(self, words):
        """
        Generate initial candidate groups of 4 words by clustering word embeddings.
        """
        embeddings = self.get_word_embeddings(words)

        # Perform Agglomerative (Hierarchical) Clustering with 4 clusters
        clustering = AgglomerativeClustering(n_clusters=4, linkage='average')
        cluster_labels = clustering.fit_predict(embeddings)

        # Group words based on their cluster labels
        clusters = [[] for _ in range(4)]
        for word, label in zip(words, cluster_labels):
            clusters[label].append(word)


        # Ensure each cluster has exactly 4 words (if not, adjust clusters or retry)
        # cleaning cluster by removing "'", " ", ","
        
        candidate_groups = [group for group in clusters if len(group) == 4]
        return candidate_groups if len(candidate_groups) == 4 else []  # Return only if valid
