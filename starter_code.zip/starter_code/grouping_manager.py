from .nlp_layer import NLPLayer
from .llm_layer import LLMLayer

MAX_RETRIES = 3  # Maximum attempts for re-evaluation of groups

class GroupingManager:
    def __init__(self, words, api_key):
        self.words = words
        self.api_key = api_key
        self.nlp_layer = NLPLayer()
        self.llm_layer = LLMLayer(api_key)
        self.invalid_words = set()  # Track invalid words from flagged groups
        self.retries = 3  # Counter for re-evaluation attempts
    
    def get_best_group(self):
        """
        Generate and evaluate groups using the NLP and LLM layers. If the LLM layer detects an invalid group,
        it triggers re-evaluation with filtered candidate groups.
        """
        candidate_groups = self.nlp_layer.get_initial_groups(self.words)
        print("Candidate groups:", candidate_groups)
        for group in candidate_groups:
            if self.retries >= MAX_RETRIES:
                break
            
            # Validate the group using LLM
            is_valid, validated_group = self.llm_layer.validate_group_with_llm(group)
            
            if is_valid:
                return validated_group, False  # Return the validated group, do not end turn
            else:
                # Update invalid words and refine candidate groups
                self.invalid_words.update(validated_group)
                candidate_groups = self.nlp_layer.get_initial_groups(self.words)
                candidate_groups = [g for g in candidate_groups if not any(w in self.invalid_words for w in g)]
                self.retries += 1  # Increase re-evaluation count

        # Fallback to highest scoring group if retries are exhausted
        best_group = max(candidate_groups, key=self.llm_layer.score_group)
        return best_group, True  # End turn if retries were exceeded
